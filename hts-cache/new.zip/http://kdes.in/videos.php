﻿<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Videos | SW Health Care </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Place favicon.ico in the root Internist, General Practitonery -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/dripicons.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/meanmenu.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="responsive.css">
</head>

<body>
   Database connected successfully  <header class="header-area">
        <div class="header-top second-header d-none d-md-block">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 d-none d-lg-block">
                    </div>
                    <div class="col-lg-6 second-header-1 col-md-8 d-none  d-md-block">
                        <div class="header-cta">
                            <ul>
                                <li>
                                    <i class="icon dripicons-mail"></i>
                                    <span> kdes2017@gmail.com </span>
                                </li>
                                <li>
                                    <i class="icon dripicons-phone"></i>
                                    <span>+91- 9555498906</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 second-header-1 col-md-3 d-none d-lg-block">
                        <div class="header-social text-right">
                            <span>
                                <a href="https://www.facebook.com/K-D-Engineering-Solutions-107106984797903" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a>
                                <a href="https://twitter.com/KapilDe32091332" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/kapil-dev-sharma-ba7791209/" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                            </span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="header-sticky" class="menu-area menu-area d-none d-lg-block">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.php"><img src="header-image/1615271827_1615197139_mainlogo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">
                            <div class="main-menu text-right pr-15">
                                <nav>
                                    <ul class="ul-reset">
                                        <li><a href='index.php'>Home</a></li>
                                        <li><a href='about.php'>About Us</a>
                                        </li><!-- .droppable -->
                                        <li class='droppable'>
                                            <a href='#'>Products</a>
                                            <div class='mega-menu'>
                                                <div class="container cf">
       <ul class="ul-reset">
           <h3>Lab Instruments</h3>
                                        <li><a href='product-subcat.php?pro_id=137'>Spare And Consumables To Laboratories</a></li>
                                        <li><a href='product-subcat.php?pro_id=138'>Environmental Instruments</a></li>
                                        <li><a href='product-subcat.php?pro_id=139'>Lab Instruments </a></li>
                                        <li><a href='product-subcat.php?pro_id=140'>Calibration Services For Instruments</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Hydrological Products</h3>
                                        <li><a href='product-subcat.php?pro_id=141'>Hydrological Products</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Air Quality Products</h3>
                                        <li><a href='product-subcat.php?pro_id=142'>Air Quality Product</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Water Testing Instruments</h3>
                                        <li><a href='product-subcat.php?pro_id=143'>Water Testing Instruments</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Servicing And Maintenance Of Equipment</h3>
                                        <li><a href='product-subcat.php?pro_id=144'>Servicing And Maintenance </a></li>
                     </ul>

                                                </div><!-- .container -->
                                            </div><!-- .mega-menu-->
                                        </li><!-- .droppable -->
                                        <li class="has-sub"> 
                      <a>Gallery</a>
                       <ul>                          
                              <li><a href="exhibition.php">Exhibition & Events</a></li>
                              <!-- <li><a href="videos.php">Videos</a></li> -->
                      </ul>
                  </li>
                  
                                         <li><a href='catalogue.php'>Catalogue</a></li> 
                                        <li><a href='contact.php'>Contact Us</a></li>
                                    </ul><!-- .container .ul-reset -->
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                            <a href="enquiry.php" class="top-btn">Enquiry <i class="fas fa-chevron-right"></i></a>

                        </div>
                        <div class="col-12">
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- start mobile menu section -->
        <nav class="navbar navbar-expand-md  navbar-dark mblnavdis">
            <!-- Brand -->
            <a class="navbar-brand" href="index.php" class=""><img src="header-image/1615271827_1615197139_mainlogo.png" alt="logo" class="mbllogo"></a>
          
            <!-- Toggler/collapsibe Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <!-- Navbar links -->
            <div class="collapse navbar-collapse posinab" id="collapsibleNavbar">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    Products
                    </a>
                    <div class="dropdown-menu">
       <ul class="ul-reset">
            <p class="mblprevensn">Lab Instruments</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=137">
                            Spare And Consumables To Laboratories                          </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=138">
                            Environmental Instruments                          </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=139">
                            Lab Instruments                           </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=140">
                            Calibration Services For Instruments                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Hydrological Products</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=141">
                            Hydrological Products                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Air Quality Products</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=142">
                            Air Quality Product                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Water Testing Instruments</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=143">
                            Water Testing Instruments                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Servicing And Maintenance Of Equipment</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=144">
                            Servicing And Maintenance                           </a>
                     </ul>


                  
                     
                    </div>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                   Gallery
                    </a>
                    <div class="dropdown-menu">
                    <ul class="ul-reset">
                    <a class="dropdown-item" href="exhibition.php">Exhibition</a>
                    <a class="dropdown-item" href="videos.php">Videos</a>
                    </ul>
                    </div>
                    </li>
                   <li class="nav-item">
                    <a class="nav-link" href="catalogue.php">Catalogue</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="enquiry.php">Enquiry</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                  </li>
              </ul>
            </div>
          </nav>
          <!-- end mobile menu section -->
    </header>    <main>
        <!-- breadcrumb-area -->
        <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(img/testimonial/test-bg.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                        <div class="breadcrumb-wrap text-center">
                            <div class="breadcrumb-title mb-30">
                                <!--                                    <h2>About Us</h2>                                    -->
                            </div>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Videos</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- about-area -->
        <section class="choose-area pt-100 pb-50 p-relative py-5">
            <div class="chosse-img wow fadeInRight animated" data-animation="fadeInRight animated" data-delay=".2s"></div>
            <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                <div class="section-title text-center mb-80">
                    <span> OUR VIDEOS</span> 
                      <h2>LATEST VIDEOS</h2>
                      <p>We have the vast range of products in the industry with a strength of over many products which caters to almost the entire spectrum of a patient’s need while assuring safety. See our products videos.</p>
                  </div>
                </div>
                <div class="col-lg-2"></div>
            </div>
            <div class="row mt-4">
                <div class="col-lg-4 mb-4">
                    <iframe width="100%" height="250" src="../brochures/KDES Ambient Air with  DMD  SOx NOx CO PM.PDF" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div class="col-lg-4 mb-4">
                    <iframe width="100%" height="250" src="../brochures/K_D_Engineering_Solutions_AAQMS.pdf" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div class="col-lg-4 mb-4">
                    <iframe width="100%" height="250" src="../brochures/KDES WATER RO, ETP, STP & WTP PRODUCT CATALOG.pdf" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div class="col-lg-4 mb-4">
                    <iframe width="100%" height="250" src="../brochures/KDES Introduction File.pdf" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>

            </div>

            </div>
        </section>
        <!-- about-area-end -->

    </main>

    <footer class="footer-bg footer-p">
        <div class="overly"><img src="img/an-bg/footer-bg.png" alt="rest"></div>
        <div class="footer-top pb-30" style="background-color: #ECF1FA;">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-xl-4 col-lg-4 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="flog ">
                                <a href="index.php"><img src="header-image/1742082421_1742082164016.jpg" alt="logo"></a>
                            </div>
                            <div class="footer-text mb-10">
                                <p>
                                    K D Engineering Solutions is a reputed manufacturer and supplier for Labs Instruments to different Industries across the nation and abroad.                                </p>
                            </div>
                            <div class="footer-social">
                               <a href="https://www.facebook.com/K-D-Engineering-Solutions-107106984797903" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://twitter.com/KapilDe32091332" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/kapil-dev-sharma-ba7791209/" target="_blank" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-2 col-lg-2 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h5>Quick Links</h5>
                            </div>
                            <div class="footer-link">
                                <ul>
                                    <li><a href="index.php"><i class="fas fa-chevron-right"></i> Home</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> About Us</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> Products</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h5>Our Products</h5>
                            </div>
                            <div class="footer-link">
                                <div class="row">
                                    <div class="col-lg-6 mblpadd">
                                        <ul>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Lab Instruments</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Hydrological Products</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i>Air Quality Products</a></li>
                                         
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 mblpadd">
                                        <ul>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Water Testing Instruments</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Servicing And Maintenance Of Equipment</a></li>
                                          
                                        </ul>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copyright-text text-center">
                            <p>Copyright &copy; 2021 K D ENGINEERING SOLUTIONS. All Rights Reserved.
							<br> Website designed and developed by <a href="http://fivedesign.in/" target="_blank" style="color:#fff;text-decoration: underline;"> Five design<br>
										  <img src="images/fivedesign-black.png" style="      filter: opacity(0.7);  width: 80px; margin-top:5px;">
							</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


     <section>
            <div class="whapspicn">
                <a href="https://wa.me/919582043336?text=" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i></a>
            </div>
        </section>
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/one-page-nav-min.js"></script>
    <script src="js/jquery.meanmenu.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/paroller.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/js_isotope.pkgd.min.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/parallax-scroll.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/element-in-view.js"></script>
    <script src="js/main.js"></script>


<!-- start tawk to section --->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f7d4632f0e7167d0016cbe4/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!-- end tawk to section --->
</body>

</html>