<!doctype html>
<html class="no-js" lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>K D ENGINEERING SOLUTIONS  </title>
        <meta name="description" content="We are the Best Medical Equipments Supplier in Bawana, Delhi. SW Health Care is amongst the leading pharmaceutical and medical equipment manufacturing companies of Central India. ">
		<meta name="keywords" content="Medical Equipments Supplier in Delhi, Best Medical Equipments Supplier in Delhi, Medical Equipments Supplier in Bawana, Best Medical Equipments Supplier in Bawana, Medical Equipment Dealers in Delhi, Medical Equipment Dealers in Bawana, Hospital Equipments Supplier in Delhi, Medical Equipments Manufacturer in Delhi, Hospital Equipments manufacturer in Bawana, medical equipments exporters in delhi">
		<meta name="google-site-verification" content="iHmPqWn9MYR__AdX4Trg9pl39VXc2zNI23Yd9wtGzFU" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root Internist, General Practitonery -->

		<!-- CSS here -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
        <link rel="stylesheet" href="css/dripicons.css">
        <link rel="stylesheet" href="css/slick.css">
        <link rel="stylesheet" href="css/default.css">
        <link rel="stylesheet" href="css/meanmenu.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/slick-theme.css">

        <link rel="stylesheet" href="responsive.css">
</head>
    <body>
        <!-- header -->
        Database connected successfully  <header class="header-area">
        <div class="header-top second-header d-none d-md-block">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 d-none d-lg-block">
                    </div>
                    <div class="col-lg-6 second-header-1 col-md-8 d-none  d-md-block">
                        <div class="header-cta">
                            <ul>
                                <li>
                                    <i class="icon dripicons-mail"></i>
                                    <span> kdes2017@gmail.com </span>
                                </li>
                                <li>
                                    <i class="icon dripicons-phone"></i>
                                    <span>+91- 9555498906</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 second-header-1 col-md-3 d-none d-lg-block">
                        <div class="header-social text-right">
                            <span>
                                <a href="https://www.facebook.com/K-D-Engineering-Solutions-107106984797903" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a>
                                <a href="https://twitter.com/KapilDe32091332" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/kapil-dev-sharma-ba7791209/" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                            </span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="header-sticky" class="menu-area menu-area d-none d-lg-block">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.php"><img src="header-image/1615271827_1615197139_mainlogo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">
                            <div class="main-menu text-right pr-15">
                                <nav>
                                    <ul class="ul-reset">
                                        <li><a href='index.php'>Home</a></li>
                                        <li><a href='about.php'>About Us</a>
                                        </li><!-- .droppable -->
                                        <li class='droppable'>
                                            <a href='#'>Products</a>
                                            <div class='mega-menu'>
                                                <div class="container cf">
       <ul class="ul-reset">
           <h3>Lab Instruments</h3>
                                        <li><a href='product-subcat.php?pro_id=137'>Spare And Consumables To Laboratories</a></li>
                                        <li><a href='product-subcat.php?pro_id=138'>Environmental Instruments</a></li>
                                        <li><a href='product-subcat.php?pro_id=139'>Lab Instruments </a></li>
                                        <li><a href='product-subcat.php?pro_id=140'>Calibration Services For Instruments</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Hydrological Products</h3>
                                        <li><a href='product-subcat.php?pro_id=141'>Hydrological Products</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Air Quality Products</h3>
                                        <li><a href='product-subcat.php?pro_id=142'>Air Quality Product</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Water Testing Instruments</h3>
                                        <li><a href='product-subcat.php?pro_id=143'>Water Testing Instruments</a></li>
                     </ul>
       <ul class="ul-reset">
           <h3>Servicing And Maintenance Of Equipment</h3>
                                        <li><a href='product-subcat.php?pro_id=144'>Servicing And Maintenance </a></li>
                     </ul>

                                                </div><!-- .container -->
                                            </div><!-- .mega-menu-->
                                        </li><!-- .droppable -->
                                        <li class="has-sub"> 
                      <a>Gallery</a>
                       <ul>                          
                              <li><a href="exhibition.php">Exhibition & Events</a></li>
                              <!-- <li><a href="videos.php">Videos</a></li> -->
                      </ul>
                  </li>
                  
                                         <li><a href='catalogue.php'>Catalogue</a></li> 
                                        <li><a href='contact.php'>Contact Us</a></li>
                                    </ul><!-- .container .ul-reset -->
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                            <a href="enquiry.php" class="top-btn">Enquiry <i class="fas fa-chevron-right"></i></a>

                        </div>
                        <div class="col-12">
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- start mobile menu section -->
        <nav class="navbar navbar-expand-md  navbar-dark mblnavdis">
            <!-- Brand -->
            <a class="navbar-brand" href="index.php" class=""><img src="header-image/1615271827_1615197139_mainlogo.png" alt="logo" class="mbllogo"></a>
          
            <!-- Toggler/collapsibe Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <!-- Navbar links -->
            <div class="collapse navbar-collapse posinab" id="collapsibleNavbar">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                    Products
                    </a>
                    <div class="dropdown-menu">
       <ul class="ul-reset">
            <p class="mblprevensn">Lab Instruments</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=137">
                            Spare And Consumables To Laboratories                          </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=138">
                            Environmental Instruments                          </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=139">
                            Lab Instruments                           </a>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=140">
                            Calibration Services For Instruments                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Hydrological Products</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=141">
                            Hydrological Products                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Air Quality Products</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=142">
                            Air Quality Product                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Water Testing Instruments</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=143">
                            Water Testing Instruments                          </a>
                     </ul>
       <ul class="ul-reset">
            <p class="mblprevensn">Servicing And Maintenance Of Equipment</p>
                                        <a class="dropdown-item" href="product-subcat.php?pro_id=144">
                            Servicing And Maintenance                           </a>
                     </ul>


                  
                     
                    </div>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                   Gallery
                    </a>
                    <div class="dropdown-menu">
                    <ul class="ul-reset">
                    <a class="dropdown-item" href="exhibition.php">Exhibition</a>
                    <a class="dropdown-item" href="videos.php">Videos</a>
                    </ul>
                    </div>
                    </li>
                   <li class="nav-item">
                    <a class="nav-link" href="catalogue.php">Catalogue</a>
                  </li>
                   <li class="nav-item">
                    <a class="nav-link" href="enquiry.php">Enquiry</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                  </li>
              </ul>
            </div>
          </nav>
          <!-- end mobile menu section -->
    </header>        <!-- header-end -->
        <!-- main-area -->
        <main>





<!-- slider-active -->
  <!-- slider-area -->
  <section id="home" class="slider-area fix p-relative">
               
               <div class=" homeslider">

                


               <div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615457139_slide.jpg')">
                       <div class="container">
                           <div class="row align-items-center">
                               <div class="col-lg-6">
                                   <div class="slider-content s-slider-content text-left">
                                       <h2 data-animation="fadeInUp" data-delay=".4s">Piezometer Digital Ground<span> Water Level Recorder</span></span></h2>
                                       <p data-animation="fadeInUp" data-delay=".6s">We set up new benchmarks in the manufacturing and exporting a wide range of Scientific Laboratory Equipment.</p>
                                       <div class="slider-btn mt-25"> 
                                       </div>
                                   </div>
                               </div>
                               <div class="col-lg-6">
                               
                               </div>
                           </div>
                       </div>
                   </div>



 


               <div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615289436_1614918171_one.png')">
                       <div class="container">
                           <div class="row align-items-center">
                               <div class="col-lg-6">
                                   <div class="slider-content s-slider-content text-left">
                                       <h2 data-animation="fadeInUp" data-delay=".4s">Manufacturer & Supplier of <span>Labs Instruments</span></span></h2>
                                       <p data-animation="fadeInUp" data-delay=".6s">KD Engineering Solutions amongst the leading laboratory equipments/instruments manufacturing companies of Central India.</p>
                                       <div class="slider-btn mt-25"> 
                                       </div>
                                   </div>
                               </div>
                               <div class="col-lg-6">
                               
                               </div>
                           </div>
                       </div>
                   </div>



 


               <div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615272036_1614918224_two.png')">
                       <div class="container">
                           <div class="row align-items-center">
                               <div class="col-lg-6">
                                   <div class="slider-content s-slider-content text-left">
                                       <h2 data-animation="fadeInUp" data-delay=".4s">Deliver Superior Quality  <span>Labs Equipments</span></span></h2>
                                       <p data-animation="fadeInUp" data-delay=".6s">We set up new benchmarks in the manufacturing and exporting a wide range of Scientific Laboratory Equipment.</p>
                                       <div class="slider-btn mt-25"> 
                                       </div>
                                   </div>
                               </div>
                               <div class="col-lg-6">
                               
                               </div>
                           </div>
                       </div>
                   </div>



	




                   <!-- <div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home2/fivedf6h/kdes.in/index.php</b> on line <b>83</b><br />
')">
                       <div class="container">
                           <div class="row align-items-center">
                               <div class="col-lg-6">
                                   <div class="slider-content s-slider-content text-left">
                                       <h2 data-animation="fadeInUp" data-delay=".4s"></h2>
                                       <p data-animation="fadeInUp" data-delay=".6s"></p>
                                       <div class="slider-btn mt-25"> 
                                       </div>
                                   </div>
                               </div>
                               <div class="col-lg-6">
                               
                               </div>
                           </div>
                       </div>
                   </div> -->
              
                   </div>                    
           
              
           </section>
           <!-- slider-area-end -->


















            <!-- slider-area -->
            <!-- <section id="home" class="slider-area fix p-relative">
                               
                <div class="slider-active">
			     

            	<div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615457139_slide.jpg')">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="slider-content s-slider-content text-left">
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Piezometer Digital Ground<span> Water Level Recorder</h2>
                                        <p data-animation="fadeInUp" data-delay=".6s">We set up new benchmarks in the manufacturing and exporting a wide range of Scientific Laboratory Equipment.</p>
                                        <div class="slider-btn mt-25"> 
                                        </div>
                                    </div>
                                </div>
								<div class="col-lg-6">
								
								</div>
                            </div>
                        </div>
                    </div>


               
                    </div>      
 
                <div class="slider-active">
			     

            	<div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615289436_1614918171_one.png')">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="slider-content s-slider-content text-left">
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Manufacturer & Supplier of <span>Labs Instruments</h2>
                                        <p data-animation="fadeInUp" data-delay=".6s">KD Engineering Solutions amongst the leading laboratory equipments/instruments manufacturing companies of Central India.</p>
                                        <div class="slider-btn mt-25"> 
                                        </div>
                                    </div>
                                </div>
								<div class="col-lg-6">
								
								</div>
                            </div>
                        </div>
                    </div>


               
                    </div>      
 
                <div class="slider-active">
			     

            	<div class="single-slider slider-bg d-flex align-items-center" style="background-image:url('header-image/1615272036_1614918224_two.png')">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="slider-content s-slider-content text-left">
                                        <h2 data-animation="fadeInUp" data-delay=".4s">Deliver Superior Quality  <span>Labs Equipments</h2>
                                        <p data-animation="fadeInUp" data-delay=".6s">We set up new benchmarks in the manufacturing and exporting a wide range of Scientific Laboratory Equipment.</p>
                                        <div class="slider-btn mt-25"> 
                                        </div>
                                    </div>
                                </div>
								<div class="col-lg-6">
								
								</div>
                            </div>
                        </div>
                    </div>


               
                    </div>      
					
               
               
            </section> -->
            <!-- slider-area-end -->
            <!-- about-area -->
            <section id="about" class="about-area about-p pt-65 pb-80 p-relative" style="background-image:url(img/an-bg/an-bg03.png); background-size: contain; background-repeat: no-repeat;background-position: center center; padding-top:80px;">
                <div class="container">
                    <div class="row align-items-center">					
                      <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="s-about-img p-relative">
                                <img src="about-image/1615272257_1615025271_about2.png
" alt="img" class="img-fluid">
                                
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="about-content s-about-content pl-30" id="ckk">
                                <div class="section-title mb-20">
                                    <span>About Us</span>                                                                      
                                </div>
                                <h2>We Are Expertise in Deliver Labs Instruments</h2>

<p>K D Engineering Solutions is a reputed manufacturer and supplier for Labs Instruments to different Industries across the nation and abroad. Our Labs instruments, comes with quality of manufacturing and accuracy of results and NABL traceable calibration certificates.</p>

<ul>
	<li>We have a wide range of high quality Labs Instruments.</li>
	<li>
	<p>We provide highest quality equipments for various applications.</p>
	</li>
	<li>
	<p>We have a decade of industry experience in manufacturing &amp; supplying.</p>
	</li>
</ul>
                               <div class="slider-btn mt-30">                                          
                                            <a href="about.php" class="btn ss-btn" data-animation="fadeInRight" data-delay=".8s">Read More <i class="fas fa-chevron-right"></i></a>					
                                        </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
            <!-- about-area-end -->
			
			<!-- counter-area -->
            <div class="counter-area pt-100 pb-100" style="background-image:url(img/an-bg/an-bg04.png); background-repeat: no-repeat; background-size: contain; ">
                <div class="container">
                    <div class="row align-items-end">
                         <div class="col-lg-3 col-md-6 col-sm-12">
                           <div class="single-counter text-center" >
							 <img src="img/icon/cunt-icon01.png" alt="img">
                                <div class="counter p-relative">
                                    <span class="count">100</span><small>+</small>                                   
                                </div>
                                <p>Experts At Work</p>                               
                            </div>
                        </div>
                      <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="single-counter text-center" >
								<img src="img/icon/cunt-icon02.png" alt="img">
                                <div class="counter p-relative">
                                    <span class="count">1470</span><small>+</small>                                   
                                </div>
                                <p>Happy Customers </p>                               
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="single-counter text-center" >
								 <img src="img/icon/cunt-icon03.png" alt="img">
                                <div class="counter p-relative">
                                   <span class="count">500</span><small>+</small>                       
                                </div>
                                <p> Lab Instruments</p>                               
                            </div>
                        </div>
                         <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="single-counter text-center" >
								 <img src="img/icon/cunt-icon04.png" alt="img">
                                <div class="counter p-relative">
                                    <span class="count">100</span><small>+</small>                      
                                </div>
                                <p>Client's Satisfaction</p>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- counter-area-end -->           
            
            <!-- blog-area-->
            <section id="blog" class="blog-area  p-relative pt-100 pb-90 fix" style="background-image:url(img/an-bg/an-bg10.png); background-size: contain;background-repeat: no-repeat;background-position: center center;">           
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-8 col-lg-10">
                            <div class="section-title text-center mb-80" >
                              <span> OUR PRODUCTS RANGE </span> 
                                <h2>What We Offers</h2>
                                <p >We have the largest portfolio in the industry with a strength of over many products which caters to almost the entire spectrum of a patient��??s need while assuring safety.</p>
                            </div>
                        </div>
                    </div>
                    <div class="row team-active">                   

                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/32095.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Lab Instruments                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=119">
                                            Ice Flaking Machine 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=119">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>



                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/8918.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Lab Instruments                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=130">
                                            Hot Plate Round 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=130">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>



                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/14679.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Water Testing Instruments                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=131">
                                            Biological Sefty Cabinet 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=131">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>



                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/5730.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Servicing And Maintenance Of Equipment                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=135">
                                            Muffle Furnace 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=135">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>



                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/26461.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Air Quality Products                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=140">
                                            Stack Sampler Gti 121 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=140">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>



                    <div class="col-xl-4">                        
                            <div class="single-post mb-30" >
                                <div class="blog-thumb">
                                        <img src="product-image/28067.jpg" alt="img">
                                    
                                </div>
                                    <div class="blog-content text-left">     
                                    <div class="b-meta mb-20">
                                       <div class="row">
                                             <div class="col-lg-12 col-md-12 ctgs">
                                               
                                              Hydrological Products                                             </div>
                                         </div>
                                    </div>
                                    <h4 class="cgname">
                                      <a href="product-details.php?pro_id=141">
                                            Rtu Unit For Water Flow Meter 
                                      </a>
                                    </h4>    
                                     <div class="blog-btn"><a href="product-details.php?pro_id=141">Read More<i class="fas fa-chevron-right"></i></a></div>                                    
                                </div>                                
                            </div>
    
          </div>


                    </div>                    
                </div>
            </section>
            <!-- blog-area-end -->	
            
            <!-- services-area -->
            <section id="services" class="services-area services-bg services-two pt-100"  style="background-image:url(img/an-bg/an-bg02.png); background-size: contain; background-repeat: no-repeat;background-position: center center;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-8 col-lg-8">
                            <div class="section-title text-center pl-40 pr-40 mb-80" >
                                <span> OUR SPECIALITIES</span>
                                <h2>Our Special Services For You</h2>
                                <p class="mt-10">To anticipate the needs of the customers or end users and translating their requirements into meaningful products.</p>
                            </div>
                        </div>
                    </div>
                    <div class="row sr-line">
                        <div class="col-lg-4 col-md-12">
                            <div class="s-single-services text-center active" >
                                <div class="services-icon">
                                    <img src="img/icon/sr-icon01.png" alt="img">
                                </div>
                                <div class="second-services-content">
                                    <h5><a >New Laboratory Set Up Consultancy</a></h5>     
                                    In order to cater the variegated demands of our clients, provide laboratory equipments & consultancy services.
  
                                   
                                </div>
								
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                             <div class="s-single-services text-center" >
                                <div class="services-icon">
                                   <img src="img/icon/sr-icon02.png" alt="img">
                                </div>
                                <div class="second-services-content">
                                    <h5><a >Calibration Services for Instruments</a></h5>  
                                    We offering you a complete choice of services which include calibration service for Instruments.  
                                     
                                </div>
								
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="s-single-services text-center" >
                                <div class="services-icon">
                                  <img src="img/icon/sr-icon03.png" alt="img">
                                </div>
                                <div class="second-services-content">
                                    <h5><a >Servicing and Maintenance of Equipment</a></h5>    
                                    We provide our laboratory equipments and their maintenance and repair services of to our valuable clients.  
                                     
                                </div>
								
                            </div>
                        </div>
                      
						
                    </div>
                    
                </div>
            </section>
            <!-- services-area-end -->  
            
           <!--  department area   -->
           <section class="department-area cta-bg pb-70 mt-10 pt-5 fix" style="background-image:url(img/an-bg/an-bg05.png); background-size: contain;">
                <div class="container">
                    <div class="row align-items-center servicmbl">
                        <div class="col-lg-6">
                            <div class="section-title mb-50  ">
                                <span>OUR SERVICES</span>
                                <h2>What We Do</h2>
                            </div>
                            <ul>
                                        <li>
                                            <div class="icon">
                                                <div><img src="img/icon/de-icon01.png" alt="de-icon"></div></div> 
                                            <a href="departments-detail.html" class="text">
                                                <h3>Annual Maintenance</h3>
                                                 All issues need to be addressed while maintaining Lab instruments capable of providing the correct equipment at the correct application.                                               <!--  All issues need to be addressed while maintaining medical equipment capable of providing the correct equipment at the correct application. -->
                                            </a>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <div><img src="img/icon/de-icon02.png" alt="de-icon"></div></div> 
                                             <a href="departments-detail.html" class="text">
                                                <h3>Spare And Consumables</h3>
                                                 We have also framed several quality policies and guidelines which are strictly followed within the organization.                                               <!--   Getting medical equipment on rent or buy at your doorstep has never been this convenient. We offers a wide range of medical equipment for rent. -->
                                            </a>
                                        </li>
                                        <li>
                                             <div class="icon">
                                                <div><img src="img/icon/de-icon03.png" alt="de-icon"></div></div> 
                                            <a href="departments-detail.html" class="text">
                                                <h3>Lab Equipments</h3>
                                                Our clients praised us for providing trustworthy equipment that helped them in reaching to the accurate and precision results.                                             <!--    We offers a wide range of medical equipment for rent or purchase making healthcare more accessible and affordable for you. -->
                                            </a>
                                        </li>                   
                                </ul>
                                             
                        </div>
					               <div class="col-lg-6">
                            <div class="s-d-img p-relative mrgmbl">
                                <img src="header-image/1615272841_1614921557_three.png" alt="img">
                            </div>
                         </div>
                    </div>
                </div>
            </section>
           
           <!--  department area   -->
           
            
            <!-- newslater-area -->
            <section class="newslater-area pb-50" style="padding:60px 0  !important;background-image: url(img/an-bg/an-bg06.png);background-position: center bottom; background-repeat: no-repeat;" >
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-xl-6 col-lg-6 ">
                            <div class="section-title mb-100 text-center">
                                <span>NEWSLETTER</span>          
                                <h2>Subscribe To Our Newsletter</h2>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <form  id="contact-form4" action="sendmail.php" method="post" class="contact-form newslater pb-130" style="padding-bottom:93px !important;">
                               <div class="form-group">
                                  <input class="form-control" id="email2" name="email" type="email" placeholder="Email Address..." required=""> 
                                  <button type="submit" class="btn btn-custom" id="send2" name="sub_submit">Subscribe <i class="fas fa-chevron-right"></i></button>
                               </div>
                               <!-- /Form-email -->	
                            </form>
                        </div>
                        <!-- <div class="col-xl-4 col-lg-4">
                            <img src="img/bg/news-illustration.png">
                        </div> -->
                    </div>
                   
                </div>
            </section>
            <!-- newslater-aread-end --> 
                    

 <!-- brand-area -->
 <div class="brand-area" style="background-image:url(img/an-bg/an-bg12.png); background-size: cover;background-repeat: no-repeat;">
                <div class="container">
                    <div class="row homeclients">


                    
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285510_eight.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285526_eleven.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand active">
                                <img src="logo-images/1615285535_five.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285545_four.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285557_nine.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285565_one.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285573_seven.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285582_six.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285590_ten.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285599_three.png" alt="img">
                            </div>
                        </div>

                        
                        <div class="col-xl-2">
                            <div class="single-brand ">
                                <img src="logo-images/1615285609_TWO.png" alt="img">
                            </div>
                        </div>

                        


                        <!-- <div class="col-xl-2">
                            <div class="single-brand active">
                                  <img src="img/brand/c-logo02.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                  <img src="img/brand/c-logo03.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                  <img src="img/brand/c-logo04.png" alt="img">
                            </div>
                        </div>
                        <div class="col-xl-2">
                            <div class="single-brand">
                                  <img src="img/brand/c-logo.png" alt="img">
                            </div>
                        </div>


                        <div class="col-xl-2">
                            <div class="single-brand">
                                  <img src="img/brand/c-logo.png" alt="img">
                            </div>
                        </div>


                        <div class="col-xl-2">
                            <div class="single-brand">
                                  <img src="img/brand/c-logo.png" alt="img">
                            </div>
                        </div> -->


                        
                    </div>
                </div>
            </div>
            <!-- brand-area-end -->










       <!-- brand-area -->
            <!-- <div class="brand-area" style="background-image:url(img/an-bg/an-bg12.png); background-size: cover;background-repeat: no-repeat;">
                <div class="container">
                    <div class="row brand-active">
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285510_eight.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285526_eleven.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand active">
                                <img src="logo-images/1615285535_five.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285545_four.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285557_nine.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285565_one.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285573_seven.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285582_six.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285590_ten.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285599_three.png" alt="img">
                            </div>
                        </div>
                        </div>
    <div class="homeclients">
                        <div class="col-xl-12">
                            <div class="single-brand ">
                                <img src="logo-images/1615285609_TWO.png" alt="img">
                            </div>
                        </div>
                        </div>

                    </div>
                </div>
            </div> -->
            <!-- brand-area-end -->
                     
			 
        </main>
        <!-- main-area-end -->
        <!-- footer -->
       <footer class="footer-bg footer-p">
        <div class="overly"><img src="img/an-bg/footer-bg.png" alt="rest"></div>
        <div class="footer-top pb-30" style="background-color: #ECF1FA;">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-xl-4 col-lg-4 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="flog ">
                                <a href="index.php"><img src="header-image/1742082421_1742082164016.jpg" alt="logo"></a>
                            </div>
                            <div class="footer-text mb-10">
                                <p>
                                    K D Engineering Solutions is a reputed manufacturer and supplier for Labs Instruments to different Industries across the nation and abroad.                                </p>
                            </div>
                            <div class="footer-social">
                               <a href="https://www.facebook.com/K-D-Engineering-Solutions-107106984797903" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://twitter.com/KapilDe32091332" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/kapil-dev-sharma-ba7791209/" target="_blank" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-2 col-lg-2 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h5>Quick Links</h5>
                            </div>
                            <div class="footer-link">
                                <ul>
                                    <li><a href="index.php"><i class="fas fa-chevron-right"></i> Home</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> About Us</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> Products</a></li>
                                    <li><a href="#"><i class="fas fa-chevron-right"></i> Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h5>Our Products</h5>
                            </div>
                            <div class="footer-link">
                                <div class="row">
                                    <div class="col-lg-6 mblpadd">
                                        <ul>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Lab Instruments</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Hydrological Products</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i>Air Quality Products</a></li>
                                         
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 mblpadd">
                                        <ul>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Water Testing Instruments</a></li>
                                            <li><a href="#"><i class="fas fa-chevron-right"></i> Servicing And Maintenance Of Equipment</a></li>
                                          
                                        </ul>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copyright-text text-center">
                            <p>Copyright &copy; 2021 K D ENGINEERING SOLUTIONS. All Rights Reserved.
							<br> Website designed and developed by <a href="http://fivedesign.in/" target="_blank" style="color:#fff;text-decoration: underline;"> Five design<br>
										  <img src="images/fivedesign-black.png" style="      filter: opacity(0.7);  width: 80px; margin-top:5px;">
							</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


     <section>
            <div class="whapspicn">
                <a href="https://wa.me/919582043336?text=" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i></a>
            </div>
        </section>         <!-- footer-end -->
        <!-- start whatsp section -->
       
        <!-- end whatsp section -->


        <script src="js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="js/vendor/jquery-1.12.4.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/one-page-nav-min.js"></script>
        <script src="js/jquery.meanmenu.min.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/ajax-form.js"></script>
        <script src="js/paroller.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/js_isotope.pkgd.min.js"></script>
        <script src="js/imagesloaded.min.js"></script>
        <script src="js/parallax.min.js"></script>
        <script src="js/jquery.waypoints.min.js"></script>
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/jquery.scrollUp.min.js"></script>
        <script src="js/parallax-scroll.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/element-in-view.js"></script>
        <script src="js/main.js"></script>
        
        <style type="text/css">
            #ckk ul li i
            {
                width: 30px;
                height: 30px;
                color:#ec0017;
                background: #294DA414 0% 0% no-repeat padding-box;
                text-align: center;
                line-height: 30px;
                border-radius: 50%;
                margin-right: 15px;

            }
        </style>

        <script type="text/javascript">
          $(document).ready(function()
          {
                   $( "#ckk ul li" ).prepend( $("<i class='fas fa-chevron-right'></i>") );
                             });

        </script>

     <script>
     $('.homeslider').slick({
  dots: true,
  infinite: true,
  arrows:false,
  speed: 300,
  autoplay: true,
  autoplaySpeed: 2000,
  slidesToShow: 1,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
     </script>




<script>
     $('.homeclients').slick({
  dots:false,
  infinite: true,
  arrows:true,
  speed: 300,
  autoplay: true,
  autoplaySpeed: 1000,
  slidesToShow: 5,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
     </script>


<!-- start tawk to section --->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f7d4632f0e7167d0016cbe4/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!-- end tawk to section --->




    </body>
    </html>